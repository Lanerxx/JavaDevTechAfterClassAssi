package date0603;

public class User {
    int account;
    int password;
    int balance;
}
